/**
 * 추천/땡큐, 댓글 관련 자바스크립트 파일
 */
 $(function() { 
 
 	// 댓글 쓰기가 클릭되면
 	$("#replyWrite").on("click", function() {
 		// 폼이 보이는 상태인지 아닌지 판단해서 처리
 		console.log($("#replyForm").css("display"));
 		console.log($("#replyForm").is(":visible"));
 		
 		if($("#replyForm").is(":visible")) {
 		
 			let $prev = $("#replyTitle").prev();
 			if(! $prev.is("#replyForm")) {
 				$("#replyForm").slideUp(300); 
 			}
 			
 			setTimeout(function(){
 				$("#replyForm").insertBefore("#replyTitle").slideDown(300);
 			}, 300);
 		
 		} else { 		
 			$("#replyForm").removeClass("d-none")
 				.css("display", "none").insertBefore("#replyTitle").slideDown(300);
 		}
 	});
 
 	$(".modifyReply").on("click", function() {
 	
 		// 폼이 보이는 상태인지 아닌지 판단해서 처리
 		
 		let replyRow = $(this).parents(".replyRow");
 		
 	
 		$("#replyForm").removeClass("d-none")
 			.css("display", "none").insertAfter(replyRow).slideDown(300);
 	});
 

 	$(".btnCommend").click(function(e) {
 			let com = $(this).attr("id"); 
 			console.log("com : ", com);
 			//let param = "recommend=" + com + "&no=" + no; 
 			$.ajax({
 				url: "recommend.ajax",
 				type: "post",
 				data: {recommend: com, no : $("#no").val()},
 				dataType: "json",
 				success: function(resData) {
 					console.log(resData);
 					let msg = com == "commend" ? "추천이" : "땡큐가";
 					alert(msg + " 반영 되었습니다.");
 					$("#commend > .recommend").text("(" + resData.recommend + ")");
 					$("#thank > .recommend").text("(" + resData.thank + ")");
 					
 				},
 				error: function(xhr, status, error) {
 					console.log("error : ", status);
 				}
 			});	
 	});
 
 });