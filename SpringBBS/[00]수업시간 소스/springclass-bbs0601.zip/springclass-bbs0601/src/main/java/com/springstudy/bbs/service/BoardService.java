package com.springstudy.bbs.service;

import java.util.List;
import java.util.Map;

import com.springstudy.bbs.domain.Board;
import com.springstudy.bbs.domain.Reply;

public interface BoardService {	
	

	// 추천/땡큐 정보를 업데이트 하고 갱신된 추천/땡큐 수를 읽어와서 반환하는 메서드
	public Map<String, Integer> recommend(int no, String recommend);
	
	// 댓글 리스트
	List<Reply> replyList(int no);
	
	// 게시 글 삭제하기
	void deleteBoard(int no);
	
	// 게시 글 수정하기
	void updateBoard(Board board);
	
	// 게시 글 수정, 삭제에서 비밀번호 체크
	boolean isPassCheck(int no, String pass);
	
	// 게시 글 리스트
	Map<String, Object> boardList(int pageNum, String type, String keyword);
	
	// 게시 글 상세보기
	Board getBoard(int no, boolean isCount);
	
	// 게시 글 쓰기
	void insertBoard(Board board);
}
