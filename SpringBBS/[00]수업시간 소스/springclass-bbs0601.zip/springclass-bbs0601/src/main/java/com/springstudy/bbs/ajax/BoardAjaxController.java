package com.springstudy.bbs.ajax;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.springstudy.bbs.service.BoardService;

@Controller
public class BoardAjaxController {

	@Autowired
	BoardService service;

	// 추천/땡큐 수 업데이트 요청을 처리하는 메서드
	@RequestMapping("/recommend.ajax")
	@ResponseBody
	public Map<String, Integer> recommend(int no, String recommend) {
		// {"recommend" : 10, "thank" : 3}
		return service.recommend(no, recommend);
	}
	
}
