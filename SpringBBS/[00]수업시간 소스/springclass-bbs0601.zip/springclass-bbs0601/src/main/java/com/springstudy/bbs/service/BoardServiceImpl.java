package com.springstudy.bbs.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springstudy.bbs.dao.BoardDao;
import com.springstudy.bbs.domain.Board;
import com.springstudy.bbs.domain.Reply;

// 비즈니스 로직을 처리하는 객체 - 필요한 데이터는 BoardDao를 이용해서 가져온다.
@Service
public class BoardServiceImpl implements BoardService {
	
	// 한 페이지에 출력할 게시 글의 수
	private static final int PAGE_SIZE = 10;
	
	// 한 페이지에 보여 줄 페이지 그룹 - 페이지 그룹으로 묶을 페이지의 수
	private static final int PAGE_GROUP = 10;

	@Autowired
	private BoardDao boardDao;
	
	// 게시 글 삭제하기
	public void deleteBoard(int no) {
		boardDao.deleteBoard(no);		
	}
	
	// 게시 글 수정하기
	public void updateBoard(Board board) {
		boardDao.updateBoard(board);
	}
	
	// 게시 글 수정, 삭제에서 비밀번호 체크
	public boolean isPassCheck(int no, String pass) {
		boolean result = false;
		
		String dbPass = boardDao.isPassCheck(no);
		if(dbPass.equals(pass)) {
			result = true;
		}
		
		return result;
	}
	
	
	@Override
	public Map<String, Object>  boardList(int pageNum, String type, String keyword) {	
		// 비즈니스 로직 처리 - 페이징 처리
		int currentPage = pageNum;
		
		// 현재 페이지의 시작행
		// 1 : 0, 2 : 10, 3:20 
		int startRow = currentPage * PAGE_SIZE - PAGE_SIZE;
		int listCount = boardDao.getBoardCount(type, keyword);
		
		List<Board> boardList = boardDao.boardList(startRow, PAGE_SIZE, type, keyword);
		
		int pageCount = listCount / PAGE_SIZE + (listCount % PAGE_SIZE == 0 ? 0 :  1);
		
		// 1				5 					9					10
		// 1 -> 1		1 -> 1			1 -> 1			11 -> 1
		// 21				25					29					30
		// 21 -> 21	21 -> 21		21 -> 21		31 -> 21
		int startPage = currentPage / PAGE_GROUP * PAGE_GROUP + 1
				- (currentPage % PAGE_GROUP == 0 ? PAGE_GROUP : 0);
		
		int endPage = startPage + PAGE_GROUP - 1;
		
		if(endPage > pageCount) {
			endPage = pageCount;
		}
		
		// 검색인지 아닌지 판단
		boolean searchOption = type.equals("null") || keyword.equals("null") ? false : true;
		
		// 뷰에 출력할 요청 처리 결과 데이터 - 모델을 Map에 저장
		Map<String, Object> modelMap = new HashMap<>();
		modelMap.put("bList", boardList);
		modelMap.put("currentPage", currentPage);
		modelMap.put("startPage", startPage);
		modelMap.put("endPage", endPage);
		modelMap.put("pageGroup", PAGE_GROUP);
		modelMap.put("listCount", listCount);
		modelMap.put("pageCount", pageCount);
		modelMap.put("searchOption", searchOption);
		if(searchOption) {
			modelMap.put("type", type);
			modelMap.put("keyword", keyword);
		}
		
		return modelMap;
	}

	@Override
	public Board getBoard(int no, boolean isCount) {	
		// 게시 글 읽은 횟수 증가
		if(isCount) {
			boardDao.incrementReadCount(no);
		}
		return boardDao.getBoard(no);
	}

	@Override
	public void insertBoard(Board board) {
		boardDao.insertBoard(board);
	}

	@Override
	public List<Reply> replyList(int no) {
		return boardDao.replyList(no);	}

	@Override
	public Map<String, Integer> recommend(int no, String recommend) {
		boardDao.updateRecommend(no, recommend);
		Board board = boardDao.getBoard(no);
		
		Map<String, Integer> map = new HashMap<>();
		map.put("recommend", board.getRecommend());
		map.put("thank", board.getThank());
		return map;
	}

}
