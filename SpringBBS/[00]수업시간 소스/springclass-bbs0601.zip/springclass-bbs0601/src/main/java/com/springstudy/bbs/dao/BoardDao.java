package com.springstudy.bbs.dao;

import java.util.List;

import com.springstudy.bbs.domain.Board;
import com.springstudy.bbs.domain.Reply;

public interface BoardDao {
	
	// 게시 글 번호에 해당하는 추천/땡큐 수를 업데이트 하는 메서드
	void updateRecommend(int no, String recommend);
	
	// 게시 글 번호에 해당하는 추천/땡큐 수 정보를 읽어오는 메서드
	Board getRecommend(int no);
	

	// no에 해당하는 비밀번호을 db 테이블에서 읽어오는 메서드
	public abstract String isPassCheck(int no);	
	
	List<Board> boardList(int startRow, int num, String type, String keyword);
	int getBoardCount(String type, String keyword);
	
	Board getBoard(int no);
	void insertBoard(Board board);
	void updateBoard(Board board);
	void deleteBoard(int no);
	void incrementReadCount(int no);
	List<Reply> replyList(int no);
}
