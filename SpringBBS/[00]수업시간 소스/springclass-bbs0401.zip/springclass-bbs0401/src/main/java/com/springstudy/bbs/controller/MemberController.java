package com.springstudy.bbs.controller;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.springstudy.bbs.domain.Member;
import com.springstudy.bbs.service.MemberService;

@Controller
@SessionAttributes({"member", "test"})
public class MemberController {
	
	@Autowired
	private MemberService service;
	
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		// 세션을 다시 시작
		session.invalidate();
		
		return "redirect:boardList";
	}
	
	
	// 로그인 폼에서 들어오는 로그인 요청을 처리하는 메서드
	@PostMapping("/login")
	public String login(Model model,  HttpSession session,
			@RequestParam("userId") String id, 
			@RequestParam("pass") String pass,
			HttpServletResponse response, PrintWriter out) {
		
		int result = service.login(id, pass);
		
		// 아이디가 존재하지 않으면 - 없다고 알림
		if(result == -1) {
			response.setContentType("text/html; charset=utf-8");
			out.println("<script>");
			out.println("	alert('아이디가 존재하지 않음');");
			out.println("	history.back();");
			out.println("</script>");
			return null;
			
		} else if(result == 0) { // 비밀번호가 다르면 - 다르다고 알림
			response.setContentType("text/html; charset=utf-8");
			out.println("<script>");
			out.println("	alert('비밀번호가 다름');");
			out.println("	history.back();");
			out.println("</script>");
			return null;
		}
		
		// 로그인 성공이면 - 세션에 회원정보 저장, 로그인 상태 값 저장
		Member member = service.getMember(id);
		session.setAttribute("isLogin", true);
		model.addAttribute("member", member);		
		
		return "redirect:/boardList";
	}
}
