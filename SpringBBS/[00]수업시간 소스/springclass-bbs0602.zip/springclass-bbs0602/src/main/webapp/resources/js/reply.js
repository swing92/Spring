/**
 * 추천/땡큐, 댓글 관련 자바스크립트 파일
 */
 $(function() {
 
 	// 댓글 쓰기 폼이 submit 될 때
 	$("#replyWriteForm").on("submit", function(e) {
 	
 		//e.preventDefault();
 		
 		if($("#replyContent").val().length < 5) {
 			alert("댓글은 5자 이상이어야 합니다.");
 			return false; 			
 		}
 		
 		// bbsNo=10&replyWriter=adim&replyContent=안녕하세요
 		let params = $(this).serialize()
 		console.log("params : " , params); 		
 		
 		$.ajax({
 			url: "replyWrite.ajax",
 			data: params,
 			type: "post",
 			dataType: "json",
 			success: function(resData) {
 				console.log(resData);
 				// 
 				$("#replyList").empty();
 				
 				$.each(resData, function(i, v) {
 					let result = 
			 					'<div class="replyRow row border border-top-0">'
			 					+ '<div class="col">'
								+ '	<div class="row p-2 bg-light">'
								+ '		<div class="col-4">'
								+ '			<span>' + v.replyWriter + '</span>'
								+ '		</div>'
								+ '		<div class="col-8 text-end">'
								+ '			<span class="me-3">' + v.regDate + '</span>'
								+ '			<button class="modifyReply btn btn-outline-success btn-sm">'
								+ '				<i class="bi bi-journal-text">수정</i>'
								+ '			</button>'
								+ '			<button class="deleteReply btn btn-outline-warning btn-sm">'
								+ '				<i class="bi bi-trash">삭제</i>'
								+ '			</button>'
								+ '			<button class="btn btn-outline-danger btn-sm"' 
								+ '				onclick="reportReply(\'' + v.no + '\')">'
								+ '				<i class="bi bi-telephone-outbound">신고</i>'
								+ '			</button>'								
								+ '		</div>'
								+ '	</div>'
								+ '	<div class="row">'
								+ '		<div class="col p-3">'
								+ '			<pre>' + v.replyContent + '</pre>'
								+ '		</div>'
								+ '	</div>'
								+ '</div>'
							+ '</div>'
							
 					$("#replyList").append(result); 					
 				}); // end $.each()
 				
 				$("#replyForm").slideUp(300)
 					.add("#replyContent").val("");
 			},
 			error: function(xhr, status, error) {
 				console.log("error : ", status);
 			}
 		});
 		
 		// 폼 전송을 취소한다.
 		return false; 		
 	});
 
 
 	// 댓글 쓰기가 클릭되면
 	$("#replyWrite").on("click", function() {
 		// 폼이 보이는 상태인지 아닌지 판단해서 처리
 		console.log($("#replyForm").css("display"));
 		console.log($("#replyForm").is(":visible"));
 		
 		if($("#replyForm").is(":visible")) {
 		
 			let $prev = $("#replyTitle").prev();
 			if(! $prev.is("#replyForm")) {
 				$("#replyForm").slideUp(300); 
 			}
 			
 			setTimeout(function(){
 				$("#replyForm").insertBefore("#replyTitle").slideDown(300);
 			}, 300);
 		
 		} else { 		
 			$("#replyForm").removeClass("d-none")
 				.css("display", "none").insertBefore("#replyTitle").slideDown(300);
 		}
 	});
 
 	$(".modifyReply").on("click", function() {
 	
 		// 폼이 보이는 상태인지 아닌지 판단해서 처리
 		
 		let replyRow = $(this).parents(".replyRow");
 		
 	
 		$("#replyForm").removeClass("d-none")
 			.css("display", "none").insertAfter(replyRow).slideDown(300);
 	});
 

 	$(".btnCommend").click(function(e) {
 			let com = $(this).attr("id"); 
 			console.log("com : ", com);
 			//let param = "recommend=" + com + "&no=" + no; 
 			$.ajax({
 				url: "recommend.ajax",
 				type: "post",
 				data: {recommend: com, no : $("#no").val()},
 				dataType: "json",
 				success: function(resData) {
 					console.log(resData);
 					let msg = com == "commend" ? "추천이" : "땡큐가";
 					alert(msg + " 반영 되었습니다.");
 					$("#commend > .recommend").text("(" + resData.recommend + ")");
 					$("#thank > .recommend").text("(" + resData.thank + ")");
 					
 				},
 				error: function(xhr, status, error) {
 					console.log("error : ", status);
 				}
 			});	
 	});
 
 });