package com.springstudy.bbs.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.springstudy.bbs.domain.Board;
import com.springstudy.bbs.domain.Reply;
import com.springstudy.bbs.service.BoardService;

@Controller
public class BoardController {
	
	private final static String DEFAULT_PATH = "/resources/upload/";
	
	
	@Autowired
	private BoardService service;
	
	@RequestMapping("/fileDownload")
	public void download(HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		
		String fileName = request.getParameter("fileName");
		String filePath = request.getServletContext().getRealPath(DEFAULT_PATH);
		
		File file = new File(filePath, fileName);
		
		response.setContentType("application/download; charset=UTF-8");
		response.setContentLength((int) file.length());
		
		fileName = URLEncoder.encode(file.getName(), "utf-8");
		System.out.println(fileName);
		
		response.setHeader("Content-Disposition", 
				"attachment; filename=\"" + fileName + "\";");
		
		response.setHeader("Content-Transfer-Encoding", "binary");
		
		OutputStream out = response.getOutputStream(); 
		FileInputStream fis = new FileInputStream(file); 
		FileCopyUtils.copy(fis, out);
		
		if(fis != null) {
			fis.close();
		}
		out.flush();
	}
	
	@PostMapping("/delete")
	public String delete(Model model, String pass, int no,
			@RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum,
			@RequestParam(value="type", required=false, defaultValue="null") String type, 
			@RequestParam(value="keyword", required=false, defaultValue="null") String keyword,
			PrintWriter out, HttpServletResponse response,
			RedirectAttributes reAttrs) {
		
		// 비밀번호가 맞는지 체크
		boolean result = service.isPassCheck(no, pass);
		
		// 비밀번호가 맞지 않으면 - 사용자에게 알림을 응답하고 프로그램 종료
		if(!result) {
			// 응답을 직접 생성
			response.setContentType("text/html; charset=utf-8");
			out.println("<script>");
			out.println("	alert('비밀번호가 맞지 않음');");
			out.println("	history.back();");
			out.println("</script>");
			return null;
		}
		
		// 비밀번호가 맞으면 게시 글을 삭제
		service.deleteBoard(no);
		
		boolean searchOption = type.equals("null") || keyword.equals("null") ? false : true;
		
		// 계속적으로 사용할 파라미터
		reAttrs.addAttribute("pageNum", pageNum);
		if(searchOption) {
			reAttrs.addAttribute("type", type);
			reAttrs.addAttribute("keyword", keyword);
		}
		
		// 게시 글 삭제가 완료되면 게시 글 리스트로 redirect
		return "redirect:boardList";
	}
	
	
	@PostMapping("/updateProcess")
	public String update(Model model, Board board,
			@RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum,
			@RequestParam(value="type", required=false, defaultValue="null") String type, 
			@RequestParam(value="keyword", required=false, defaultValue="null") String keyword,
			PrintWriter out, HttpServletResponse response,
			RedirectAttributes reAttrs) {
		
		// 비밀번호가 맞는지 체크
		boolean result = service.isPassCheck(board.getNo(), board.getPass());
		
		// 비밀번호가 맞지 않으면 - 사용자에게 알림을 응답하고 프로그램 종료
		if(!result) {
			// 응답을 직접 생성
			response.setContentType("text/html; charset=utf-8");
			out.println("<script>");
			out.println("	alert('비밀번호가 맞지 않음');");
			out.println("	history.back();");
			out.println("</script>");
			return null;
		}
				
		// 게시 글을 수정
		service.updateBoard(board);
		
		
		boolean searchOption = type.equals("null") || keyword.equals("null") ? false : true;
		
		// 계속적으로 사용할 파라미터
		reAttrs.addAttribute("pageNum", pageNum);
		if(searchOption) {
			reAttrs.addAttribute("type", type);
			reAttrs.addAttribute("keyword", keyword);
		}
		
		// 1회성 파라미터
		reAttrs.addFlashAttribute("test", "1회성 파라미터 test");
		
		// 게시 글 수정이 완료되면 redirect
		return "redirect:boardList";
	}
	
	
	@PostMapping("/update")
	public String update(Model model, String pass, int no,
			@RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum,
			@RequestParam(value="type", required=false, defaultValue="null") String type, 
			@RequestParam(value="keyword", required=false, defaultValue="null") String keyword,
			PrintWriter out, HttpServletResponse response) {

		// 비밀번호가 맞는지 체크
		boolean result = service.isPassCheck(no, pass);
		
		// 비밀번호가 맞지 않으면 - 사용자에게 알림을 응답하고 프로그램 종료
		if(!result) {
			// 응답을 직접 생성
			response.setContentType("text/html; charset=utf-8");
			out.println("<script>");
			out.println("	alert('비밀번호가 맞지 않음');");
			out.println("	history.back();");
			out.println("</script>");
			return null;
		}
		
		boolean searchOption = type.equals("null") || keyword.equals("null") ? false : true;
		
		// 비밀번호가 맞으면 - no에 해당하는 게시 글 정보를 읽어와 모델에 저장
		model.addAttribute("board", service.getBoard(no, false));
		model.addAttribute("pageNum", pageNum);
		model.addAttribute("searchOption", searchOption);
		if(searchOption) {
			model.addAttribute("type", type);
			model.addAttribute("keyword", keyword);
		}
		
		
		return "/updateForm";
	}
	
	//@RequestMapping("/writeProcess")
	// 파라미터를 받아서 도메인 객체로 넘겨주는 커멘트 객체
	@PostMapping("/writeProcess")
	public String insertBoard(HttpServletRequest request,
			String title, String writer, String content, String pass,
			@RequestParam(value="file1", required=false) MultipartFile multipartFile
			) throws IllegalStateException, IOException {

		System.out.println("original name : " + multipartFile.getOriginalFilename());
		System.out.println("file name : " + multipartFile.getName());
		
		Board board = new Board();
		board.setTitle(title);
		board.setWriter(writer);
		board.setPass(pass);
		board.setContent(content);	
		
		if(! multipartFile.isEmpty()) { // 파일 업로드 처리
			String filePath = request.getServletContext().getRealPath(DEFAULT_PATH);
			
			UUID uid = UUID.randomUUID();
			String saveName = uid.toString() + "_" + multipartFile.getOriginalFilename();
			File file = new File(filePath, saveName);
			System.out.println("new fileName : " + file.getName());
			
			// file 객체의 path 위치에 업로드된 파일을 복사 
			multipartFile.transferTo(file);
			board.setFile1(saveName);
		}
		
		// 입력 - Board 객체로 만들어서	
		// 게시 글 등록 => service
		service.insertBoard(board);		
		
		// 최종적으로 응답 
		return "redirect:boardList";
	}
	
	
	// 페이징, 게시 글 조회 횟수 처리, 
	@GetMapping("/boardDetail")
	public String boardDetail(Model model, int no,
			@RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum,
			@RequestParam(value="type", required=false, defaultValue="null") String type, 
			@RequestParam(value="keyword", required=false, defaultValue="null") String keyword) {
		
		boolean searchOption = type.equals("null") || keyword.equals("null") ? false : true;
		
		Board board = service.getBoard(no, true);
		List<Reply> replyList = service.replyList(no);
		
		model.addAttribute("board", board);
		model.addAttribute("replyList", replyList);
		model.addAttribute("pageNum", pageNum);
		model.addAttribute("searchOption", searchOption);
		if(searchOption) {
			model.addAttribute("type", type);
			model.addAttribute("keyword", keyword);
		}
		
		return "/boardDetail";
	}
	
	
	@RequestMapping(value={"/boardList", "/list"}, method=RequestMethod.GET)
	public String boardList(Model model, 
			@RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum,
			@RequestParam(value="type", required=false, defaultValue="null") String type, 
			@RequestParam(value="keyword", required=false, defaultValue="null") String keyword) {
		
		// 1. 입력
		//String page = request.getParameter("page");
		
		// 2. 요청에 대한 처리를 하고 결과 데이터 - 게시 글 리스트 - 모델(model)
		Map<String, Object> modelMap = service.boardList(pageNum, type, keyword);
		model.addAllAttributes(modelMap);
		
		// 3. 뷰에 결과를 출력
		// 뷰의 이름으로 간주 - viewResolver 설정의 prefix, suffix를 조합해서 물리적인 뷰의 이름이 결정 
		// /WEB-INF/index.jsp?body=views/ + boardList + .jsp
		return "boardList";
	}

	
}
