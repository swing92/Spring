package com.springstudy.bbs.service;

import com.springstudy.bbs.domain.Member;

public interface MemberService {
	
	// 회원 정보 수정시 비밀번호 체크
	public boolean memberPassCheck(String id, String pass);
	
	// 회원 정보 수정
	public void updateMember(Member m);
	
	// 로그인 처리 
	public int login(String id, String pass);
	
	// 회원 정보를 dao를 통해서 가져오는 메서드
	public Member getMember(String id);
	
	// 회원 아이디 중복 검사 메서드
	public boolean overlapIdCheck(String id); 
	
	// 회원 등록하는 메서드
	public void addMember(Member member);

}
