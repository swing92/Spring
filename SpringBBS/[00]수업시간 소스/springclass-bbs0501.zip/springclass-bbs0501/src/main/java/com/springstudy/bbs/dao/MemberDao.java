package com.springstudy.bbs.dao;

import com.springstudy.bbs.domain.Member;

public interface MemberDao {
	public Member getMember(String id);
	public void addMember(Member member);
	
}
