package com.springstudy.bbs.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.springstudy.bbs.dao.MemberDao;
import com.springstudy.bbs.domain.Member;

@Service
public class MemberServiceImpl implements MemberService {
	
	@Autowired
	private MemberDao memberDao;
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	@Override
	public int login(String id, String pass) {
		
		int result = -1;
		Member member = memberDao.getMember(id);
		if(member == null) { // id가 존재하지 않으면
			return result;
		}
		
		if(passwordEncoder.matches(pass, member.getPass())) {
			result = 1;
			
		} else {
			result = 0;
		}
		
		return result;
	}

	@Override
	public Member getMember(String id) {		
		return memberDao.getMember(id);
	}

	@Override
	public boolean overlapIdCheck(String id) {
		Member member = memberDao.getMember(id);
		if(member == null) {
			return false;
		}
		return true;
	}

	@Override
	public void addMember(Member member) {
		//  비밀번호 암호화 
		member.setPass(passwordEncoder.encode(member.getPass()));
		
		System.out.println(member.getPass());
		memberDao.addMember(member);		
	}

}
