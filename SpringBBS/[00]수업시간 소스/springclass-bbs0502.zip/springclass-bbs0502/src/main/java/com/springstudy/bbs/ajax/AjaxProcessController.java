package com.springstudy.bbs.ajax;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.springstudy.bbs.service.MemberService;

@Controller
public class AjaxProcessController {
	
	@Autowired
	private MemberService service;
	
	// 뷰가 있나요? JSON(JavaScript Object Notation)
	// [{"result": "false"}, ...]
	@RequestMapping("/passCheckAjax")
	@ResponseBody
	public Map<String, Object> memberPassCheck(String id, String pass) {
		boolean result = service.memberPassCheck(id, pass);
		Map<String, Object> map = new HashMap<>();
		map.put("result", result);		
		
		return map;
	}
}
