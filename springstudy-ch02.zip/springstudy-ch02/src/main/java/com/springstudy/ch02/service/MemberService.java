package com.springstudy.ch02.service;

import java.util.ArrayList;

import com.springstudy.ch02.domain.Member;

public interface MemberService {
	public ArrayList<Member> getMemberList();
}
