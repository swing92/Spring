package com.springstudy.ch04.dao;

public interface FirstMvcDao {
	public abstract String getMessage(int no, String id);	
}
