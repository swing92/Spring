package com.springstudy.ch02.dao;

import java.util.ArrayList;

import com.springstudy.ch02.domain.Member;

public interface MemberDAO {
	public ArrayList<Member> getMemberList();
}
